
#ifdef __XC16__
  #include <xc.h>
#else
  #include "p33Fxxxx.h"
#endif

#include "initIO.h"
#include "fft32b.h"

#include "dsp.h"


//----------------------------------------------------- 

#ifndef dsPIC33EP

_FOSCSEL(FNOSC_FRC & IESO_OFF); // Select FRC as primary oscillator; Disable clock switching
_FWDT(FWDTEN_OFF);              // Watchdog Timer controlled by SW      
_FICD(JTAGEN_OFF & ICS_PGD3);   // Disable JTAG; Use EMUC3/EMUD3 for emulator communication

#endif

//timijk 
long ipFftBuff[REAL_N] __attribute__ ((space(ymemory),far,aligned(256)));
//long ipFftBuff[REAL_N] __attribute__ ((space(xmemory),far,aligned(256)));

int i;


//----------------------------------------------------- 
	
int main()
{
    int j=0;
    
    initIO();                                          // Initialize I/O control

	while(1) 
    {				
        Nop();                                         // First BREAK POINT to observe output	
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
        Nop();
			
        for(i=0;i<REAL_N;i++)
        {
            if(j++<8) ipFftBuff[i]=50;
            else ipFftBuff[i]=-50;
            
            ipFftBuff[i]=ipFftBuff[i]<<16;
            
            j %= 16;
        }
        
        Nop();                                         // Second BREAK POINT to observe input		
        Nop();
        Nop();
        Nop();

                                                       // ### Add FFT call here		
#if(PSV_TF)
        FFTReal32bIP(REAL_LOGN,REAL_N,ipFftBuff,psvTwdlFctr32b,__builtin_psvpage(&psvTwdlFctr32b));
#else
        FFTReal32bIP(REAL_LOGN,REAL_N,ipFftBuff,ramTwdlFctr32b,0xFF00);
#endif
        // ### Add FFT Magnitude call here
        MagnitudeCplx32bIP((REAL_N/2)+1,ipFftBuff);
	}
}


/**********************************************************************
* � 2011 Microchip Technology Inc.
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Inc. (�Microchip�) licenses this software to you
* solely for use with Microchip dsPIC� digital signal controller
* products. The software is owned by Microchip and is protected under
* applicable copyright laws.  All rights reserved.
*
* SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP EXPRESSLY DISCLAIMS ANY
* WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
* PARTICULAR PURPOSE, OR NON-INFRINGEMENT. IN NO EVENT SHALL MICROCHIP
* BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST OF
* PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
* BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF),
* ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
**********************************************************************/
