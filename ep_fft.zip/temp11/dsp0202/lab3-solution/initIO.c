
#ifdef __XC16__
  #include <xc.h>
#else
  #include "p33Fxxxx.h"
#endif

//----------------------------------------------------- 

void initIO(void)               
{
	TRISBbits.TRISB12=0;            // LED D4
	TRISBbits.TRISB13=0;            // LED D5		
	TRISBbits.TRISB14=0;            // LED D6
	TRISBbits.TRISB15=0;            // LED D7	

	LATBbits.LATB12=1;              // LED D4 off
	LATBbits.LATB13=1;              // LED D5 off
	LATBbits.LATB14=1;              // LED D6 off
	LATBbits.LATB15=1;              // LED D7 off

	TRISBbits.TRISB5=1;             // Configure PORTB RB5 pin as input to read wwitch SW1

#ifdef dsPIC33EP
    ANSELA=0x0000;
    ANSELB=0x0000;   
#else
	AD1PCFGL=0xFFFF;                // Configure all ANx pins as Digital 
#endif
}


/**********************************************************************
* � 2011 Microchip Technology Inc.
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Inc. (�Microchip�) licenses this software to you
* solely for use with Microchip dsPIC� digital signal controller
* products. The software is owned by Microchip and is protected under
* applicable copyright laws.  All rights reserved.
*
* SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP EXPRESSLY DISCLAIMS ANY
* WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
* PARTICULAR PURPOSE, OR NON-INFRINGEMENT. IN NO EVENT SHALL MICROCHIP
* BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST OF
* PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
* BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF),
* ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
**********************************************************************/
