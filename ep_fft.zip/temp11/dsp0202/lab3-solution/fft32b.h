/**********************************************************************
* � 2005 Microchip Technology Inc.
*
* FileName:        fft32b.h
* Dependencies:    Other (.h) files if applicable, see below
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v2.01.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Inc. (�Microchip�) licenses this software to you
* solely for use with Microchip dsPIC� digital signal controller
* products. The software is owned by Microchip and is protected under
* applicable copyright laws.  All rights reserved.
*
* SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP EXPRESSLY DISCLAIMS ANY
* WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
* PARTICULAR PURPOSE, OR NON-INFRINGEMENT. IN NO EVENT SHALL MICROCHIP
* BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST OF
* PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
* BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF),
* ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
*
* REVISION HISTORY:
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date      Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* MCHP 				07/09/06  First release of source file
* SEC               07/01/10  Updated for RTC
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
*
**********************************************************************/

#ifndef __FFT32B_H__
#define __FFT32B_H__ 

                                    // Specify Twiddle Factor Placement 
                                    // 1 - Twiddle Factor is placed in Program FLASH Memory, Accessed using PSV 
#define PSV_TF  1                   // 0 - Twiddle Factor is placed in Data RAM Memory
//timijk change 1 to 0                   
                                    
                                    // Specify Size of Real FFT
#define REAL_N  64                  // 64,128,256,512,1024 point Real FFT is supported

                                    // Specify Number of Stage in FFT = LOG2(N)/2
#define REAL_LOGN   5               // 9 stage for 512 complex FFT


#if(PSV_TF)                         
    extern int psvTwdlFctr32b[] __attribute__ ((space(psv)));
#else
    extern long ramTwdlFctr32b[] __attribute__ ((far));
#endif


#endif
