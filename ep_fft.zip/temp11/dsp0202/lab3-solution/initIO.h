#ifndef __INIT_IO_H__

    #define __INIT_IO_H__ 
    extern void initIO(void);

#endif
